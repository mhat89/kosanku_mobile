import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/cupertino.dart';
import 'views/map/map_screen.dart';

void main() {
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) {
    return CupertinoApp(
      debugShowCheckedModeBanner: false,
      builder: BotToastInit(),                      // <- aktifkan BotToast
      navigatorObservers: [BotToastNavigatorObserver()],
      home: const MapScreen(),
    );
  }
}
