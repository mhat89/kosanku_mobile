import 'package:latlong2/latlong.dart';

class Kosan {
  final String id;
  final String name;
  final String address;
  final LatLng latLng;

  const Kosan({
    required this.id,
    required this.name,
    required this.address,
    required this.latLng,
  });

  factory Kosan.fromJson(Map<String, dynamic> j) => Kosan(
    id: j['id'].toString(),
    name: j['name'] ?? j['nama'] ?? 'Kosan',
    address: j['address'] ?? j['alamat'] ?? '',
    latLng: LatLng(
      (j['lat'] as num).toDouble(),
      (j['lng'] as num).toDouble(),
    ),
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'address': address,
    'lat': latLng.latitude,
    'lng': latLng.longitude,
  };
}
