import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

import '../models/kosan.dart';

class LeafletMapView extends StatefulWidget {
  final LatLng? myLocation;
  final List<Kosan> kosan;

  /// Garis rute (opsional)
  final List<LatLng> route;

  /// Info rute opsional untuk ditampilkan
  final double? routeDistanceM;
  final double? routeDurationS;

  /// Callback saat kosan di-tap
  final ValueChanged<Kosan>? onKosanTap;

  const LeafletMapView({
    super.key,
    required this.myLocation,
    required this.kosan,
    this.route = const [],
    this.routeDistanceM,
    this.routeDurationS,
    this.onKosanTap,
  });

  @override
  State<LeafletMapView> createState() => _LeafletMapViewState();
}

class _LeafletMapViewState extends State<LeafletMapView> {
  final _map = MapController();

  @override
  void didUpdateWidget(covariant LeafletMapView oldWidget) {
    super.didUpdateWidget(oldWidget);

    // Center peta ke lokasi user ketika lokasi tersedia pertama kali
    if (oldWidget.myLocation == null && widget.myLocation != null) {
      _map.move(widget.myLocation!, 16);
      BotToast.showText(text: 'GPS locked');
    }

    // Tampilkan info rute kalau ada
    if (widget.route.isNotEmpty &&
        (oldWidget.routeDistanceM != widget.routeDistanceM ||
            oldWidget.routeDurationS != widget.routeDurationS)) {
      final d = widget.routeDistanceM ?? 0.0;
      final t = widget.routeDurationS ?? 0.0;
      final min = (t / 60).ceil();
      BotToast.showText(
          text:
          'Rute: ${(d / 1000).toStringAsFixed(2)} km • ±$min menit (perkiraan)');
      _fitBoundsForRoute();
    }
  }

  void _fitBoundsForRoute() {
    if (widget.route.length < 2) return;

    final latitudes = widget.route.map((e) => e.latitude).toList()..sort();
    final longitudes = widget.route.map((e) => e.longitude).toList()..sort();

    final sw = LatLng(latitudes.first, longitudes.first);
    final ne = LatLng(latitudes.last, longitudes.last);

    _map.fitCamera(
      CameraFit.bounds(
        bounds: LatLngBounds(sw, ne),
        padding: const EdgeInsets.all(36),
      ),
    );
  }

  void _showKosanSheet(BuildContext context, Kosan k) {
    showCupertinoModalPopup(
      context: context,
      builder: (_) => CupertinoActionSheet(
        title: Text(k.name),
        message: Text(k.address, maxLines: 3, overflow: TextOverflow.ellipsis),
        actions: [
          CupertinoActionSheetAction(
            onPressed: () {
              Navigator.pop(context);
              widget.onKosanTap?.call(k);
            },
            child: const Text('Detail / Arahkan'),
          ),
        ],
        cancelButton: CupertinoActionSheetAction(
          onPressed: () => Navigator.pop(context),
          isDefaultAction: true,
          child: const Text('Tutup'),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final center = widget.myLocation ?? const LatLng(-6.200000, 106.816666);

    return Stack(
      children: [
        FlutterMap(
          mapController: _map,
          options: MapOptions(
            initialCenter: center,
            initialZoom: 14,
          ),
          children: [
            // Tile Leaflet (OSM)
            TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
              userAgentPackageName: 'com.example.kosanku_mobile',
              retinaMode: true,
              maxZoom: 19,
              tileBounds: LatLngBounds(
                LatLng(-85.05112878, -180.0),
                LatLng(85.05112878, 180.0),
              ),
            ),

            // Polyline rute (opsional)
            if (widget.route.isNotEmpty)
              PolylineLayer(
                polylines: [
                  Polyline(
                    points: widget.route,
                    strokeWidth: 5,
                    color: const Color(0xFF007AFF), // iOS blue
                  ),
                ],
              ),

            // Marker lokasi saya
            if (widget.myLocation != null)
              MarkerLayer(markers: [
                Marker(
                  point: widget.myLocation!,
                  width: 42,
                  height: 42,
                  child: const Icon(
                    CupertinoIcons.location_solid,
                    color: CupertinoColors.activeBlue,
                    size: 34,
                  ),
                ),
              ]),

            // Marker kosan + popup custom (action sheet)
            MarkerLayer(
              markers: widget.kosan
                  .map(
                    (k) => Marker(
                  point: k.latLng,
                  width: 44,
                  height: 44,
                  child: GestureDetector(
                    onTap: () => _showKosanSheet(context, k),
                    child: const Icon(
                      CupertinoIcons.house_fill,
                      color: CupertinoColors.systemRed,
                      size: 36,
                    ),
                  ),
                ),
              )
                  .toList(),
            ),
          ],
        ),

        // Search bar dummy (hanya UI)
        Positioned(
          left: 16,
          right: 16,
          top: 12,
          child: _SearchBar(
            onSubmit: (text) {
              BotToast.showText(text: 'Cari: $text');
            },
          ),
        ),
      ],
    );
  }
}

class _SearchBar extends StatefulWidget {
  final ValueChanged<String>? onSubmit;
  const _SearchBar({this.onSubmit});

  @override
  State<_SearchBar> createState() => _SearchBarState();
}

class _SearchBarState extends State<_SearchBar> {
  final c = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: const BorderRadius.all(Radius.circular(14)),
      child: Container(
        color: const Color(0xCC000000), // dark blur-ish
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Row(
          children: [
            const Icon(CupertinoIcons.search, color: CupertinoColors.white),
            const SizedBox(width: 8),
            Expanded(
              child: CupertinoTextField.borderless(
                controller: c,
                placeholder: 'Cari kosan / daerah…',
                placeholderStyle:
                const TextStyle(color: CupertinoColors.systemGrey4),
                style: const TextStyle(color: CupertinoColors.white),
                onSubmitted: widget.onSubmit,
              ),
            ),
            const SizedBox(width: 8),
            CupertinoButton(
              padding: EdgeInsets.zero,
              onPressed: () => widget.onSubmit?.call(c.text),
              child: const Icon(CupertinoIcons.arrow_right_circle_fill,
                  color: CupertinoColors.white),
            ),
          ],
        ),
      ),
    );
  }
}
