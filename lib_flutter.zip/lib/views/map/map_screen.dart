import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/cupertino.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';

import 'package:kosanku_mobile/models/kosan.dart';
import 'package:kosanku_mobile/widgets/leaflet_map_view.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  LatLng? _me;
  final _kosan = <Kosan>[
    const Kosan(
      id: 'k1',
      name: 'Kosan Mawar',
      address: 'Jakarta Pusat',
      latLng: LatLng(-6.1975, 106.8320),
    ),
    const Kosan(
      id: 'k2',
      name: 'Kosan Melati',
      address: 'Setiabudi',
      latLng: LatLng(-6.2170, 106.8250),
    ),
  ];

  List<LatLng> _route = const [];
  double? _routeDistanceM;
  double? _routeDurationS;

  @override
  void initState() {
    super.initState();
    _initLocation();
  }

  Future<void> _initLocation() async {
    try {
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
        if (perm == LocationPermission.denied) {
          BotToast.showText(text: 'Izin lokasi ditolak');
          return;
        }
      }
      if (perm == LocationPermission.deniedForever) {
        BotToast.showText(text: 'Izin lokasi permanen ditolak (Settings).');
        return;
      }
      if (!await Geolocator.isLocationServiceEnabled()) {
        BotToast.showText(text: 'Location Service nonaktif.');
        return;
      }

      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      setState(() => _me = LatLng(pos.latitude, pos.longitude));
    } catch (e) {
      BotToast.showText(text: 'Gagal mendapatkan lokasi: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return CupertinoPageScaffold(
      child: SafeArea(
        bottom: false,
        child: LeafletMapView(
          myLocation: _me,
          kosan: _kosan,
          route: _route,
          routeDistanceM: _routeDistanceM,
          routeDurationS: _routeDurationS,
          onKosanTap: (k) {
            if (_me == null) {
              BotToast.showText(text: 'Lokasi saya belum siap');
              return;
            }
            // DEMO: garis lurus dari posisi user ke kosan
            final pts = [_me!, k.latLng];
            final dist = Distance()(pts.first, pts.last); // meter
            setState(() {
              _route = pts;
              _routeDistanceM = dist;
              _routeDurationS = (dist / 75) * 60; // ~75 m/menit → detik
            });

            // Nanti ganti ke ORS / Google Directions:
            // final r = await DI.routing.route(from: _me!, to: k.latLng);
            // setState(() {
            //   _route = r.points;
            //   _routeDistanceM = r.distanceMeters;
            //   _routeDurationS = r.durationSeconds;
            // });
          },
        ),
      ),
    );
  }
}
